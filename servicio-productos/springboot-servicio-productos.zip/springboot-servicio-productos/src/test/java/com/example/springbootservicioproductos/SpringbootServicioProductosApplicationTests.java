package com.example.springbootservicioproductos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootServicioProductosApplicationTests {

	@Test
	void contextLoads() {
	}

}
